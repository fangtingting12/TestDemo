package com.aikaifa.imageviewpager;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.aikaifa.imageviewpager.ImageCycleView.ImageCycleViewListener;
import com.example.imageviewpager.R;
/*
 * 
 * Android QQ����Ⱥ��  154950206
 * ΢�źŰ�����  :aikaifa
 */
public class MainActivity extends Activity {

	private ImageCycleView mAdView;
	private ArrayList<String> mImageUrl = null;
	
	private ArrayList<String> mImageTitle = null;
	private String imageUrl1 = "https://ss3.baidu.com/9fo3dSag_xI4khGko9WTAnF6hhy/news/q=100/sign=854bc2a175cf3bc7ee00c9ece101babd/83025aafa40f4bfb19afa0f8064f78f0f736181a.jpg";
	private String imageUrl2 = "https://ss2.baidu.com/-vo3dSag_xI4khGko9WTAnF6hhy/news/q=100/sign=9f3227a309d79123e6e090749d355917/9825bc315c6034a80b6dcf2ace13495408237689.jpg";
	private String imageUrl3 = "https://ss1.baidu.com/9vo3dSag_xI4khGko9WTAnF6hhy/news/q=100/sign=32bf684cf203918fd1d139ca613c264b/3b87e950352ac65c41a059dffef2b21192138af0.jpg";
	
	private String imageTitle1 = "����";
	private String imageTitle2 = "����";
	private String imageTitle3 = "����";

	public int stype=1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mImageUrl = new ArrayList<String>();
		mImageUrl.add(imageUrl1);
		mImageUrl.add(imageUrl2);
		mImageUrl.add(imageUrl3);
		
		
		mImageTitle = new ArrayList<String>();
		mImageTitle.add(imageTitle1);
		mImageTitle.add(imageTitle2);
		mImageTitle.add(imageTitle3);
		mAdView = (ImageCycleView) findViewById(R.id.ad_view);
		mAdView.setImageResources(mImageUrl ,mImageTitle, mAdCycleViewListener,stype);
	}

	private ImageCycleViewListener mAdCycleViewListener = new ImageCycleViewListener() {
		@Override
		public void onImageClick(int position, View imageView) {
			
			
			Toast.makeText(MainActivity.this, mImageUrl.get(position)+position, 1).show();
		}
	};
}
